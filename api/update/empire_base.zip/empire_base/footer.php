
	    <footer class="footer" id="footer">

	      <div class="container"></div>

	    </footer>

    </div>

    <?php wp_footer(); ?>

  </body>

</html>